import axios from 'axios'
import { ElMessage } from 'element-plus'

const request = axios.create({
  baseURL: '/api',
  timeout: 15000
})

// 请求拦截器 - 添加 token
request.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = 'Bearer ' + token
    }
    return config
  },
  error => Promise.reject(error)
)

// 响应拦截器 - 统一处理
request.interceptors.response.use(
  res => {
    // 后端返回 code: 0 表示成功
    if (res.data.code !== 0 && res.data.code !== 200) {
      ElMessage.error(res.data.msg || res.data.message || '请求失败')
      // 401/403 都跳登录
      if (res.data.code === 401 || res.data.code === 403) {
        localStorage.removeItem('token')
        window.location.href = '/login'
      }
      return Promise.reject(res.data)
    }
    return res.data.data || res.data
  },
  err => {
    const msg = err.response?.data?.msg || err.response?.data?.message || '网络错误'
    ElMessage.error(msg)
    if (err.response?.status === 401 || err.response?.status === 403) {
      localStorage.removeItem('token')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export default request
