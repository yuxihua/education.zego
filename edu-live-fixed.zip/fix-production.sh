#!/bin/bash
# ==========================================
# 教培直播系统 - 生产环境完整修复脚本
# 修复：权限控制 + Token 传递 + 直播创建
# ==========================================

set -e

echo "========== 开始修复 =========="

# 后端目录
BACKEND_DIR="/var/www/education.zego/edu-live-server"
FRONTEND_DIR="/var/www/education.zego/edu-live-admin"

echo "[1/5] 修复后端 auth.js..."
cat > "$BACKEND_DIR/middleware/auth.js" << 'AUTHEOF'
/**
 * JWT 认证中间件
 */
const jwt = require('jsonwebtoken');
const { fail } = require('../utils/response');
const redis = require('../config/redis');

const JWT_SECRET = process.env.JWT_SECRET || 'edu_live_default_secret';
const JWT_EXPIRE = process.env.JWT_EXPIRE || '7d';

function generateToken(payload, expiresIn = JWT_EXPIRE) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn });
}

function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (err) {
    return null;
  }
}

async function auth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return fail(res, '请先登录', 401, 401);
    }
    const token = authHeader.substring(7);
    const decoded = verifyToken(token);
    if (!decoded) {
      return fail(res, '登录已过期，请重新登录', 401, 401);
    }
    const isBlacklisted = await redis.get(`token:blacklist:${token}`);
    if (isBlacklisted) {
      return fail(res, '登录已失效，请重新登录', 401, 401);
    }
    req.user = decoded;
    req.token = token;
    next();
  } catch (err) {
    return fail(res, '认证失败', 401, 401);
  }
}

function requireRole(roles = []) {
  return (req, res, next) => {
    if (!req.user) {
      return fail(res, '请先登录', 401, 401);
    }
    // superadmin 可以访问所有
    if (req.user.role === 'superadmin') {
      return next();
    }
    if (!roles.includes(req.user.role)) {
      return fail(res, '权限不足', 403, 403);
    }
    next();
  };
}

module.exports = {
  auth,
  requireRole,
  generateToken,
  verifyToken
};
AUTHEOF

echo "[2/5] 修复后端 live.js..."
cat > "$BACKEND_DIR/routes/live.js" << 'LIVEEOF'
const express = require('express');
const router = express.Router();
const { LiveRoom } = require('../models');
const { success, fail } = require('../utils/response');
const { asyncHandler } = require('../middleware/error');
const { auth, requireRole } = require('../middleware/auth');
const redis = require('../config/redis');

// 查询直播间列表（公开）
router.get('/rooms', asyncHandler(async (req, res) => {
  const { page = 1, pageSize = 10, status } = req.query;
  const where = {};
  if (status) where.status = status;
  const { count, rows } = await LiveRoom.findAndCountAll({
    where, order: [['createdAt', 'DESC']],
    offset: (page - 1) * pageSize, limit: parseInt(pageSize)
  });
  success(res, { list: rows, pagination: { total: count, page: parseInt(page), pageSize: parseInt(pageSize) } });
}));

// 查询直播间详情（公开）
router.get('/room/:id', asyncHandler(async (req, res) => {
  const room = await LiveRoom.findByPk(req.params.id);
  if (!room) return fail(res, '直播间不存在', 404);
  success(res, room);
}));

// 创建直播间（需要登录 + admin/teacher/superadmin）
router.post('/room', auth, requireRole(['admin', 'superadmin', 'teacher']), asyncHandler(async (req, res) => {
  const { courseId, title, password, teacherId } = req.body;
  const tid = teacherId || req.user.id;
  const room = await LiveRoom.create({
    courseId: courseId || 1,
    zegoRoomId: 'edu_' + Date.now(),
    title: title || '未命名直播间',
    teacherId: tid,
    anchorId: tid,
    anchorName: req.user.nickname || req.user.username || '讲师',
    onlineCount: 0,
    peakCount: 0,
    totalViewCount: 0,
    password: password || null,
    status: 'upcoming',
    chatEnabled: true,
    allMuted: false
  });
  success(res, room, '创建成功');
}));

// 开始直播
router.post('/room/:id/start', auth, requireRole(['admin', 'superadmin', 'teacher']), asyncHandler(async (req, res) => {
  const room = await LiveRoom.findByPk(req.params.id);
  if (!room) return fail(res, '直播间不存在', 404);
  await room.update({ status: 'living', actualStartTime: new Date() });
  success(res, null, '直播已开始');
}));

// 结束直播
router.post('/room/:id/stop', auth, requireRole(['admin', 'superadmin', 'teacher']), asyncHandler(async (req, res) => {
  const room = await LiveRoom.findByPk(req.params.id);
  if (!room) return fail(res, '直播间不存在', 404);
  await room.update({ status: 'finished', endTime: new Date() });
  success(res, null, '直播已结束');
}));

// 暂停直播
router.post('/room/:id/pause', auth, asyncHandler(async (req, res) => {
  await LiveRoom.update({ status: 'paused' }, { where: { id: req.params.id } });
  success(res, null, '已暂停');
}));

// 恢复直播
router.post('/room/:id/resume', auth, asyncHandler(async (req, res) => {
  await LiveRoom.update({ status: 'living' }, { where: { id: req.params.id } });
  success(res, null, '已恢复');
}));

// 全员禁言
router.post('/room/:id/chat/mute-all', auth, asyncHandler(async (req, res) => {
  await LiveRoom.update({ allMuted: req.body.mute }, { where: { id: req.params.id } });
  success(res, null, req.body.mute ? '已禁言' : '已解除禁言');
}));

// 聊天历史
router.get('/room/:id/chat/history', asyncHandler(async (req, res) => {
  const messages = await redis.lrange('chat:' + req.params.id, 0, 49);
  success(res, messages.map(m => JSON.parse(m)).reverse());
}));

// 用户进入
router.post('/room/:id/online', asyncHandler(async (req, res) => {
  const { userId } = req.body;
  await redis.sadd('room:' + req.params.id + ':online', userId || 'guest_' + Date.now());
  await redis.expire('room:' + req.params.id + ':online', 3600);
  const onlineCount = await redis.scard('room:' + req.params.id + ':online');
  await LiveRoom.update({ onlineCount }, { where: { id: req.params.id } });
  success(res, { onlineCount });
}));

// 用户离开
router.post('/room/:id/offline', asyncHandler(async (req, res) => {
  const { userId } = req.body;
  if (userId) await redis.srem('room:' + req.params.id + ':online', userId);
  const onlineCount = await redis.scard('room:' + req.params.id + ':online');
  await LiveRoom.update({ onlineCount }, { where: { id: req.params.id } });
  success(res, { onlineCount });
}));

module.exports = router;
LIVEEOF

echo "[3/5] 修复前端 request.js..."
cat > "$FRONTEND_DIR/src/api/request.js" << 'REQEOF'
import axios from 'axios'
import { ElMessage } from 'element-plus'

const request = axios.create({
  baseURL: '/api',
  timeout: 15000
})

// 请求拦截器 - 添加 token
request.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = 'Bearer ' + token
    }
    return config
  },
  error => Promise.reject(error)
)

// 响应拦截器
request.interceptors.response.use(
  res => {
    if (res.data.code !== 0 && res.data.code !== 200) {
      ElMessage.error(res.data.msg || res.data.message || '请求失败')
      if (res.data.code === 401 || res.data.code === 403) {
        localStorage.removeItem('token')
        window.location.href = '/login'
      }
      return Promise.reject(res.data)
    }
    return res.data.data || res.data
  },
  err => {
    const msg = err.response?.data?.msg || err.response?.data?.message || '网络错误'
    ElMessage.error(msg)
    if (err.response?.status === 401 || err.response?.status === 403) {
      localStorage.removeItem('token')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export default request
REQEOF

echo "[4/5] 重建前端..."
cd "$FRONTEND_DIR"
npm run build

echo "[5/5] 重启后端..."
cd "$BACKEND_DIR"
pm2 reload edu-live-server

echo ""
echo "========== 修复完成 =========="
echo ""
echo "请刷新页面，重新登录后再试创建直播间"
echo ""
