<template>
  <div class="watch-live">
    <!-- 顶部栏 -->
    <div class="header">
      <div class="live-info">
        <el-tag v-if="isLiving" type="danger" effect="dark">● 直播中</el-tag>
        <el-tag v-else-if="isWaiting" type="primary">即将开始</el-tag>
        <el-tag v-else type="info">已结束</el-tag>
        <span class="title">{{ roomInfo?.title || '直播间' }}</span>
      </div>
      <div class="online">在线 {{ onlineCount }} 人</div>
    </div>

    <div class="main">
      <!-- 左侧：视频 + 白板 -->
      <div class="left">
        <!-- 视频区域 -->
        <div class="video-box" v-show="!isWhiteboardFull">
          <div id="remote-video" class="video-player"></div>
          <div class="video-placeholder" v-if="!isLiving">
            <el-icon size="48"><VideoCamera /></el-icon>
            <p>{{ isWaiting ? '直播即将开始，请稍候...' : '直播已结束' }}</p>
          </div>
        </div>

        <!-- 白板区域 -->
        <div class="whiteboard-box" :class="{ fullscreen: isWhiteboardFull }">
          <div class="wb-toolbar" v-if="isTeacher">
            <el-button-group>
              <el-button size="small" @click="setWbTool('selector')">选择</el-button>
              <el-button size="small" @click="setWbTool('pen')">画笔</el-button>
              <el-button size="small" @click="setWbTool('text')">文字</el-button>
              <el-button size="small" @click="setWbTool('eraser')">橡皮</el-button>
            </el-button-group>
            <el-color-picker v-model="wbColor" size="small" @change="setWbColor" />
          </div>
          <div class="whiteboard" ref="whiteboardRef"></div>
          <div class="wb-page" v-if="totalPage > 1">
            <el-button size="small" @click="prevPage" :disabled="currentPage <= 1">上一页</el-button>
            <span>{{ currentPage }} / {{ totalPage }}</span>
            <el-button size="small" @click="nextPage" :disabled="currentPage >= totalPage">下一页</el-button>
            <el-button size="small" @click="isWhiteboardFull = !isWhiteboardFull">
              {{ isWhiteboardFull ? '退出全屏' : '全屏' }}
            </el-button>
          </div>
        </div>
      </div>

      <!-- 右侧：聊天 -->
      <div class="right">
        <div class="chat-box">
          <div class="chat-header">课堂互动</div>
          <div class="chat-messages" ref="chatScrollRef">
            <div v-for="msg in messages" :key="msg.id" class="chat-msg" :class="{ self: msg.isSelf, system: msg.isSystem }">
              <div class="msg-header">
                <span class="msg-name">{{ msg.userName }}</span>
                <span class="msg-time">{{ msg.time }}</span>
              </div>
              <div class="msg-content">{{ msg.content }}</div>
            </div>
          </div>
          <div class="chat-input">
            <el-input v-model="chatText" placeholder="输入消息..." @keyup.enter="sendChat">
              <template #append><el-button @click="sendChat">发送</el-button></template>
            </el-input>
          </div>
        </div>

        <!-- 操作按钮 -->
        <div class="actions" v-if="isWaiting">
          <el-button type="primary" size="large" style="width: 100%" @click="subscribeLive">
            <el-icon><Bell /></el-icon> 开播提醒
          </el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, nextTick } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'

const route = useRoute()
const roomId = route.params.id

// 学生身份（通过URL参数 ?role=teacher 可切换为老师视角）
const isTeacher = ref(route.query.role === 'teacher')

// 直播状态
const roomInfo = ref({})
const isLiving = ref(false)
const isWaiting = ref(true)
const onlineCount = ref(0)

// 白板
const whiteboardRef = ref(null)
const isWhiteboardFull = ref(false)
const wbColor = ref('#000000')
const currentPage = ref(1)
const totalPage = ref(1)

// 聊天
const messages = ref([])
const chatText = ref('')
const chatScrollRef = ref(null)

// ZEGO
let zg = null
let zegoRoomID = ''

const ZEGO_CONFIG = {
  appID: 0, // 你的 ZEGO appID
  server: '', // 你的 ZEGO server
  tokenUrl: '/api/zego/token'
}

// 加载 ZEGO SDK
const loadZegoSDK = () => {
  return new Promise((resolve, reject) => {
    if (window.ZegoExpressEngine) { resolve(); return }
    const script = document.createElement('script')
    script.src = 'https://zego-im-sdk.s3.cn-north-1.amazonaws.com.cn/zegocloud/web/ZegoExpressEnginewebrtc-3.7.0.js'
    script.onload = resolve
    script.onerror = reject
    document.head.appendChild(script)
  })
}

// 初始化 ZEGO（学生 - 拉流观看）
const initZego = async () => {
  await loadZegoSDK()
  const ZegoExpressEngine = window.ZegoExpressEngine
  zg = new ZegoExpressEngine(ZEGO_CONFIG.appID, ZEGO_CONFIG.server)

  // 监听房间用户变化
  zg.on('roomUserUpdate', (roomID, updateType, userList) => {
    if (updateType === 'ADD') onlineCount.value += userList.length
    else onlineCount.value = Math.max(0, onlineCount.value - userList.length)
  })

  // 监听流变化（老师推流）
  zg.on('roomStreamUpdate', async (roomID, updateType, streamList) => {
    if (updateType === 'ADD') {
      for (const stream of streamList) {
        if (!stream.streamID.includes('screen')) {
          // 播放老师的视频
          await zg.startPlayingStream(stream.streamID, {
            video: document.getElementById('remote-video'),
            audio: true
          })
          isLiving.value = true
          isWaiting.value = false
        }
      }
    } else {
      // 流停止 = 直播结束
      isLiving.value = false
    }
  })

  // 监听 IM 消息
  zg.on('IMRecvBroadcastMessage', (roomID, chatData) => {
    chatData.forEach(msg => {
      try {
        const data = JSON.parse(msg.message)
        if (data.type === 'chat') {
          messages.value.push({
            id: Date.now() + Math.random(),
            userName: msg.fromUser.userName,
            content: data.content,
            time: new Date().toLocaleTimeString(),
            isSelf: false
          })
          scrollToBottom()
        }
      } catch (e) {}
    })
  })
}

// 进入房间（学生）
const enterRoom = async () => {
  try {
    // 获取直播间信息
    const res = await fetch(`/api/live/room/${roomId}`)
    const data = await res.json()
    roomInfo.value = data.data || {}
    zegoRoomID = roomInfo.value.zegoRoomId || 'room_' + roomId

    // 初始化 ZEGO
    await initZego()

    // 登录房间（学生身份）
    const userID = 'student_' + Date.now()
    const token = await getToken(userID)
    await zg.loginRoom(zegoRoomID, token, {
      userID,
      userName: '学生' + Math.floor(Math.random() * 1000)
    })

    // 上报在线
    await fetch(`/api/live/room/${roomId}/online`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: userID })
    })

    // 如果有回放，显示回放
    if (roomInfo.value.replayUrl) {
      isLiving.value = false
      isWaiting.value = false
    }

    ElMessage.success('已进入直播间')
  } catch (err) {
    console.error('进入直播失败:', err)
    ElMessage.error('进入直播失败: ' + err.message)
  }
}

// 获取 Token
const getToken = async (userID) => {
  const res = await fetch(`${ZEGO_CONFIG.tokenUrl}?userID=${userID}&roomID=${zegoRoomID}`)
  const data = await res.json()
  return data.token
}

// 发送聊天
const sendChat = async () => {
  if (!chatText.value.trim()) return

  const msg = { type: 'chat', content: chatText.value.trim() }
  await zg.sendBroadcastMessage(zegoRoomID, JSON.stringify(msg))

  messages.value.push({
    id: Date.now(),
    userName: '我',
    content: chatText.value,
    time: new Date().toLocaleTimeString(),
    isSelf: true
  })

  chatText.value = ''
  scrollToBottom()
}

const scrollToBottom = () => {
  nextTick(() => {
    if (chatScrollRef.value) {
      chatScrollRef.value.scrollTop = chatScrollRef.value.scrollHeight
    }
  })
}

// 白板操作
const setWbTool = (tool) => { /* 学生端只读，老师端可操作 */ }
const setWbColor = (color) => { }
const prevPage = () => { if (currentPage.value > 1) currentPage.value-- }
const nextPage = () => { if (currentPage.value < totalPage.value) currentPage.value++ }

// 订阅开播提醒
const subscribeLive = () => {
  ElMessage.success('已设置开播提醒，直播开始时会通知您')
}

// 生命周期
onMounted(() => {
  enterRoom()
})

onBeforeUnmount(() => {
  if (zg) {
    zg.logoutRoom(zegoRoomID)
    zg.destroyEngine()
  }
})
</script>

<style scoped>
.watch-live {
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: #1a1a2e;
  color: #fff;
}

.header {
  height: 48px;
  background: #16213e;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  border-bottom: 1px solid #0f3460;
}

.live-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.title {
  font-size: 16px;
  font-weight: 600;
}

.online {
  color: #aaa;
  font-size: 14px;
}

.main {
  flex: 1;
  display: flex;
  overflow: hidden;
}

.left {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 12px;
  gap: 12px;
}

.video-box {
  height: 50%;
  min-height: 200px;
  background: #0f0f23;
  border-radius: 8px;
  position: relative;
  overflow: hidden;
}

.video-player {
  width: 100%;
  height: 100%;
}

.video-player :deep(video) {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.video-placeholder {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #666;
  gap: 12px;
}

.whiteboard-box {
  flex: 1;
  background: #fff;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.whiteboard-box.fullscreen {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1000;
  border-radius: 0;
}

.wb-toolbar {
  height: 40px;
  background: #f5f5f5;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 0 12px;
  border-bottom: 1px solid #ddd;
}

.whiteboard {
  flex: 1;
  background: #fff;
}

.wb-page {
  height: 40px;
  background: #f5f5f5;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  color: #333;
  font-size: 14px;
}

.right {
  width: 320px;
  background: #16213e;
  border-left: 1px solid #0f3460;
  display: flex;
  flex-direction: column;
}

.chat-box {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.chat-header {
  height: 44px;
  background: #16213e;
  display: flex;
  align-items: center;
  padding: 0 16px;
  font-weight: 600;
  border-bottom: 1px solid #0f3460;
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.chat-msg {
  font-size: 13px;
}

.msg-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 4px;
}

.msg-name {
  color: #409EFF;
  font-weight: 600;
  font-size: 12px;
}

.msg-time {
  color: #666;
  font-size: 11px;
}

.msg-content {
  background: #0f3460;
  padding: 8px 12px;
  border-radius: 8px;
  word-break: break-all;
}

.chat-msg.self .msg-name {
  color: #67C23A;
}

.chat-msg.self .msg-content {
  background: #1f4f28;
}

.chat-input {
  padding: 12px;
  border-top: 1px solid #0f3460;
}

.actions {
  padding: 12px;
  border-top: 1px solid #0f3460;
}
</style>
